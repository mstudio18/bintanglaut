###################
Simple CI Crud + image
###################
CRUD simple menggunakan Codeigniter dengan upload gambar


*******
Fitur
*******
1. CRUD
2. Pagination
3. Upload Image
4. Search


*******
Setting
*******
a. Buat database bernama crud
b. import databasenya(crud.sql)
c. setting config database pada codeigniternya
d. ubah base_url sesuai struktur folder masing-masing
